a=int(input())
b=int(input())
print("Addition: %d"%(a+b))
print("Concatenation: %s"%(str(a)+str(b)))