mid=float(input())
fin=float(input())
print("Total:",mid+fin)
print("Average:",(mid+fin)/2)