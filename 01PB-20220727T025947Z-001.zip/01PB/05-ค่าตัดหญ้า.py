a=int(input("Enter block length: "))
b=int(input("Enter block width: "))
c=int(input("Enter house length: "))
d=int(input("Enter house width: "))
ans=(a*b-c*d)*35
print("Mowing cost is %d baht."%(ans))