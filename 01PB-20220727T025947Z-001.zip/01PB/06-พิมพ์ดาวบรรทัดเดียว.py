n=int(input())
c=input()
print(n*c)