r=int(input("Enter a radius: "))
import math
area=math.pi*r**2
c=2*math.pi*r
print("Area of a circle with radius %d is %.2f"%(r,area))
print("Circumference of a circle with radius %d is %.2f"%(r,c))