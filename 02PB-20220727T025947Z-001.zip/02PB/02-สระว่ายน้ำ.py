w=float(input("Enter width: "))
l=float(input("Enter length: "))
d=float(input("Enter depth: "))
t=w*l*d
tt=t/4
print("Time to fill a pool is %.2f minutes."%(tt))