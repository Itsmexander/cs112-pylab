inc=float(input())
ex=float(input())

print("Total Income%+9.2f bahts"%(inc))
print("Expense%14.2f bahts"%(ex))
print("Profit       %08.2f bahts"%(inc+ex))