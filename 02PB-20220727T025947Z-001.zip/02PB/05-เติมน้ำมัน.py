distance=float(input())
capacity=float(input())

kaew=int((distance/15)/(0.5*capacity))
kwan=int((distance/15)/(0.9*capacity))

print("%d\n%d"%(kaew+1,kwan+1))