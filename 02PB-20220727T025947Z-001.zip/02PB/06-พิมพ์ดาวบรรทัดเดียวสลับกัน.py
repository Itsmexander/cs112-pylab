n=int(input())
a=input()
b=input()
x=a+b
q=n//2
w=n%2
d=(x*q)+(w*a)
print(d)