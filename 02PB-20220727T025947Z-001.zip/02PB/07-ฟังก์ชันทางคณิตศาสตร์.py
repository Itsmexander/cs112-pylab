x=float(input("Enter x: "))
y=float(input("Enter y: "))
z=float(input("Enter z: "))
a1=x**y+z
print("a1 = %.2f"%(a1))
import math
a2=math.cos(2*math.pi)+math.log(x)
print("a2 = %.2f"%(a2))
a3=abs(x)+abs(y)
print("a3 = %.2f"%(a3))
a4=(x**2+y**2+z**2)**0.5
print("a4 = %.2f"%(a4))
a5=math.sin(x)*math.sin(x)+math.cos(x)*math.cos(x)
print("a5 = %.2f"%(a5))
a6=(x+y)**0.2
print("a6 = %.2f"%(a6))
a7=math.e**(x*(math.log(y,math.e)))
print("a7 = %.2f"%(a7))