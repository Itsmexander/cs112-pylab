a=float(input('Enter buying amount: '))
if 1000<=a<3000:
    b=a*0.9
elif a>=3000:
    b=a*0.85
else:
    b=a
print('Amount due after discount is %.2f baht.'%(b))