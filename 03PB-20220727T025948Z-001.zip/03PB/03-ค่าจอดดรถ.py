h=float(input("Enter number of hours: "))
m=float(input("Enter number of minutes: "))
x=h*60+m
import math
if h<0 or m<0 or m>=60:
  print("Input Error!")
elif 0<=x<=15:
  print("No charge, thanks.")
elif x<=120:
  print("Total amount due is 10 Bahts.")
else:
  p=math.ceil((x-120)/60)*10+10
  print("Total amount due is %d Bahts."%(p))
