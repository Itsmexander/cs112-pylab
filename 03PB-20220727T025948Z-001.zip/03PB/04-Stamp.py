a=float(input('Total Price: '))
print('You got: %d'%(a//50))