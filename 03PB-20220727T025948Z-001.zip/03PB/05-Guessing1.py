target = 72

a=int(input('Enter your guess (0 - 100): '))
if a == target:
    print('Congratulations, your guess is correct.')
elif 0<=a<=100 and a!=target:
    print('Sorry, your guess is wrong, try again later.')
else:
    print('Sorry, out of range, try again later.')