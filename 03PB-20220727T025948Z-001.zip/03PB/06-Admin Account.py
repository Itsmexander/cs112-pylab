ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'Ad31n15Tr@t012'

u = input('Username: ')
p = input('Password: ')
if u == ADMIN_USERNAME and p == ADMIN_PASSWORD:
    print('Welcome, admin.')
else:
    print('You are not admin.')