x=float(input('Enter x : '))
import math
if x<0 :
    b=(x**2+1)**0.5
    print('f(%.2f) = %d'%(x,math.ceil(b)))
elif x==0:
    print('f(0.00) = 0')
elif 0<x<=99 :
    b=3*x**2-(1-x)**2
    print('f(%.2f) = %d'%(x,math.ceil(b)))
else:
    b=2*x**3-x/(x+1)**0.5
    print('f(%.2f) = %d'%(x,math.ceil(b)))