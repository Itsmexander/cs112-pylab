a = int(input("Enter your guess (0 - 100): "))
if a == target:
    print("Congratulations, your guess is correct.")
elif 0 <= a < target:
    print("Sorry, your guess is too low, try again later.")
elif target < a <= 100:
    print("Sorry, your guess is too high, try again later.")
else:
    print("Sorry, out of range, try again later.")