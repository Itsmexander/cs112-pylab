print("---<< Main Menu >>---\n    <B>urger Meal\n    <C>hicken Meal\n    <P>asta Meal")

main=input("Enter your choice: ")
if main=="b" or main=="B":
  print("---<< Burger Sub Menu >>---\n    <R>egular Burger\n    <C>heese Burger\n    <D>ouble Cheese Burger")
  sub=input("Enter your choice: ")
  if sub=="r" or sub=="R":
    print("Your Regular Burger is 60 Baht.")
  elif sub=="c" or sub=="C":
    print("Your Cheese Burger is 75 Baht.")
  elif sub=="d" or sub=="D":
    print("Your Double Cheese Burger is 90 Baht.")
  else:
    print("Invalid sub menu choice.")

elif main=="c" or main=="C":
  print("---<< Chicken Sub Menu >>---\n    <F>ried Chicken\n    <G>rilled Chicken\n    <C>hef's Chicken")
  sub=input("Enter your choice: ")
  if sub=="f" or sub=="F":
    print("Your Fried Chicken is 120 Baht.")
  elif sub=="g" or sub=="G":
    print("Your Grilled Chicken is 150 Baht.")
  elif sub=="c" or sub=="C":
    print("Your Chef's Chicken is 180 Baht.")
  else:
    print("Invalid sub menu choice.")

elif main=="p" or main=="P":
  print("---<< Pasta Sub Menu >>---\n    <S>paghetti de Italiano\n    <L>asagna Supreme\n    <M>acaroni Special")
  sub=input("Enter your choice: ")
  if sub=="s" or sub=="S":
    print("Your Spaghetti de Italiano is 90 Baht.")
  elif sub=="l" or sub=="L":
    print("Your Lasagna Supreme is 120 Baht.")
  elif sub=="m" or sub=="M":
    print("Your Macaroni Special is 100 Baht.")
  else:
    print("Invalid sub menu choice.")

else:
  print("Invalid main menu choice.")