tv=int(input("How many TVs? "))
dvd=int(input("How many DVD players? "))
audio=int(input("How many Audio Systems? "))

total=float(tv*6000+dvd*1500+audio*3000)

print("Total price is %.2f baht."%(total))

if total<24000:
  payment=total
else:
  payment=total*0.8
  discount=total*0.2
  print("You've got a discount of %.2f baht."%(discount))

print("Your payment is %.2f baht. Thank you!"%(payment))