a=input("Enter your buffet choice: ")
if a=="Korean" or a=="Japanese":
    b=input("Is today Wednesday (yes/no)? ")
    if a=="Korean":
        payment = 1500
        if b=="yes":
            p=payment*0.85
        else:
            p=payment
        
    else :
        payment = 1000
        if b=="yes":
            p=payment*0.85
        else:
            p=payment
    print("Your payment is %.2f Baht."%(p))
else :
    print("Sorry, there is no %s buffet."%(a))
