age=int(input("Enter your age: "))
income=float(input("Enter your net income: "))
if 15<=age<=60 and 1<=income<=79999:
    if 1<=income<=30000:
        ni=income*0.2
    else :
        ni=(30000*0.2)-((income-30000)*0.12)
        
    print("Your negative income tax is %.2f Baht."%(ni))
   
elif 15>age or age>60:
  print("Invalid age.")

elif income>=80000:
  print("Invalid income.")
