l=int(input("Enter level pokemon: "))
x=input("Enter level pokeball: ")
d=int(input("Enter distance: "))

if x=="H" or x=="h":
    x=0.01
    
elif x=="M" or x=="m":
    if 0<=l<=40:
        x=0.03
    elif 41<=l<=60:
        x=0.05 
    else :
        x=0.08
    
else:
    if 0<=l<=40:
        x=0.05
    elif 41<=l<=60:
        x=0.03 
    else :
        x=0.1
        
s=100-(l*d*x)
if s<0:
    s=0
elif s>100:
    s=100
else :
    s=s
print("%.2f percent."%(s))
