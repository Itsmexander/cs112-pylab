time=int(input("Minutes before due: "))
temp=float(input("Temperature: "))
rain=input("Is it raining (y/n)? ")

day=time//1440
if time%1440>=720:
    day=day+1
else:
    day=day
    
print(">>> %d days before due."%(day))

if day<2 :
    print(">>> I will do the assignment.")

elif day>5:
    print(">>> I will not do the assignment.")    
    
elif temp>40:
    print(">>> I will not do the assignment.")
        
elif temp>25 and (rain=="y" or rain=="Y"): 
    print(">>> I will not do the assignment.")
    
else:
    print(">>> I will do the assignment.")