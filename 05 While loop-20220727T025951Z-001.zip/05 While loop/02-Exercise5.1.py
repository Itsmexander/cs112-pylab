import math
mx = -(math.inf)
mn = math.inf
s = 0
n = 0
while n >= 0 :
    a = input()
    if a == '':
        break
    else :
        a = float(a) 
        if mx < a :
            mx=a
        if mn > a :
            mn=a
        if a >= 0:
            s+=a
    n+=1
print("%.2f %.2f\n%.2f %.2f"%(mx,mn,s,s/n))