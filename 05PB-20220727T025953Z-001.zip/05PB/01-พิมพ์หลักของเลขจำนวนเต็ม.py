num=int(input())
if num>0:
    while num>0:
        print(num%10)
        num = num//10
else:
    print('ERROR')