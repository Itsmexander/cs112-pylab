hours = int(input('Enter number of hours (0-20): '))
minutes = int(input('Enter number of minutes (0-59): '))
buyAmt = int(input('Enter shopping amount: '))

import math


p=0
total=hours*60+minutes
time=math.ceil(total/60)

if hours<0 or minutes<0 or minutes>=60:
    print('Invalid time.')
elif hours==20 and minutes>=1:
    print('Invalid time.')
elif hours>20 :
    print('Invalid time.')
elif time<=2:
    print('No charge, thank you.')
elif buyAmt>=3001:
    print('No charge, thank you.')
else:
    while time>0:
        if time<=2:
            d=0
            p=p+d
        elif 3<=time<=4:
            if buyAmt>=300:
                d=0
            else:
                d=20
            p=p+d
        elif time>=5:
            
            d=50
            p=p+d
        time=time-1
    print('Total amount due is %d Baht, thank you.'%p)