number = int(input("Enter number: "))
count = 0
while number > -1 :
    if (number %2 == 1):
        count+=1
    number = int(input("Enter number: "))
print("Received %d odd numbers" %count)