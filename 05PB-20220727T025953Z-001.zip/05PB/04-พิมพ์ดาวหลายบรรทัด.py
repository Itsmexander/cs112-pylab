n=int(input())
c=input()
count=1

while count<=n:
    print(c*count)
    count+=1