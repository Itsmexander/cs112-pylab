h=int(input('Enter height: '))
count=1
n=1

while count<=h:
    if count==1:
        print(' '*((h-1)*2)+'1')
    else:
        print(' '*((h-count)*2)+'1'+' '*(n*2+1)+'1')
        n=n+2
    count+=1