a=int(input())
r=0
if a%9==0:
    while a>0:
        s=a%10
        a=a//10 
        r=r+s
    print('Yes %d'%r)
else:
    s=a%9
    print('No %d'%s)
