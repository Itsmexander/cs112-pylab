f = int(input("Enter a target (4-digit integer): "))
s = int(input("Enter your guess (4-digit integer): "))
p=0
i=0
b1=f%10
b2=s%10
c1=(f//10)%10
c2=(s//10)%10
d1=(f//100)%10
d2=(s//100)%10
e1=(f//1000)%10
e2=(s//1000)%10


if b1==b2:
    p+=1
if c1==c2:
    p+=1
if d1==d2:
    p+=1
if e1==e2:
    p+=1

if b1==c2 or b1==d2 or b1==e2:
    i+=1
if c1==b2 or c1==d2 or c1==e2:
    i+=1
if d1==b2 or d1==c2 or d1==e2:
    i+=1
if e1==b2 or e1==c2 or e1==d2:
    i+=1

if p==0 :
    po = "No positions correct, "
elif p==1:
    po = "One position correct, "
elif p==2:
    po = "Two positions correct, "
elif p==3:
    po = "Three positions correct, "

if i==0 :
    di = "no digits correct"
elif i==1:
    di = "one digit correct"
elif i==2:
    di = "two digits correct"
elif i==3:
    di = "three digits correct"
elif i==4:
    di = "four digits correct"
    
if f==s:
    print("Congratulations, you just mastered my mind!!")
else:
    print("%s%s"%(po,di))