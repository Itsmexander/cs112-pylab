n=0
target=72

while True:
    a=int(input('Enter your guess: '))
    if a==target:
        n+=1
        print('Congratulations, your guess is correct.')
        break
    elif 0<=a<target:
        n+=1
        print('Sorry, your guess is too low.')
        continue
    elif target<a<=100:
        n+=1
        print('Sorry, your guess is too high.')
        continue
    else:
        n+=1
        print('Sorry, your guess is out of range.')
        continue
print('Total number of guesses is %d.'%n)
