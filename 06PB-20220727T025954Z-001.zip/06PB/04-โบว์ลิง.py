frame=1
p=0
n=0
a=0
while frame<=10:
    print('Frame # %d'%frame)    
    p=int(input('  Number of pins down: '))
    n=n+p
    if p!=10  :
        frame=frame
        print('Frame # %d'%frame)
        p=int(input('  Number of pins down (0-%d): '%(10-p)))
        n=n+p
        frame=frame+1
        
    else:
        frame+=1

print('Total score is %d'%n)
        
        
    
