tall = int(input())
count = 0
most = tall
if tall > 0:
    count +=1
while (tall != -1):
    tall = int(input())
    if (tall > most):
        most = tall
        count+=1
print(count)