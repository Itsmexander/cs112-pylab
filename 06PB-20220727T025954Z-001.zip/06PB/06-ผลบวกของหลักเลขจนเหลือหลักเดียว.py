a=int(input())
x = 0
while a > 0:
    x += a%10
    a = a//10
while x > 9:
    a = x%10
    b = x//10
    x = a+b
print(x)
