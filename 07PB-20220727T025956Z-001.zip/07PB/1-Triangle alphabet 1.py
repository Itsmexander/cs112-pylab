n=int(input('Enter a number: '))
count=0
i=0
if n<=0 or n>26:
    print('Invalid input, program terminates.')
else:
    while count<n:
        count+=1
        while True:
            if i<count: 
                print(chr(ord('A')+i),end='')
            else:
                break
            i+=1
        print()
        i=0
