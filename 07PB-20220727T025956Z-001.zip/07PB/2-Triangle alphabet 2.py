n=int(input('Enter a number: '))
count=0
a=n
i=0
if n<=0 or n>26:
    print('Invalid input, program terminates.')
else:
    while a>0:
        count-=1
        while True:
            if i<a: 
                print(chr(ord('A')+i),end='')
            else:
                break
            i+=1
        a-=1
        print()
        i=0
