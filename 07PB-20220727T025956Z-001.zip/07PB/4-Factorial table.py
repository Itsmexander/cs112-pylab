a=int(input('Enter a number: '))
count=0
b=1
c=1
if a<0:
    print('Invalid input, program terminates.')
else:
    while count<=a:
        if count==0:
            print('0! = 1 = 1')
        elif count==1:
            print('1! = 1 = 1')
        else:
            print('%d! = %d '%(count,count),end='')
            i=count
            while i>1:
                i-=1
                print('x %d '%(i),end='')
            while True:
                if b<=count:
                    c=c*b
                    b+=1
                else:
                    break
            print('= %d'%c)
                    
        count+=1