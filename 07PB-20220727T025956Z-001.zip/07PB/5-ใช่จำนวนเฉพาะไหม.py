n=int(input('Enter a number: '))
count=2
total=0
while n!=0:
    if n<=1:
        print('Invalid input, try again.')
        n=int(input('Enter a number: '))
    else:
        while count<n:
            a=n%count
            if a!=0:
                total=total+count
            else:
                total=total+0
            count+=1
        if total==(n*(n-1)/2)-1:
            print('%d is a prime number.'%n)
            n=int(input('Enter a number: '))
            total=0
            count=2
        else:
            print('%d is not a prime number.'%n)
            n=int(input('Enter a number: '))
            total=0
            count=2
print('End of program, goodbye.')

