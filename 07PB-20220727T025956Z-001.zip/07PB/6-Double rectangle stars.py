h=int(input('Enter height: '))
w=int(input('Enter width: '))
count=1
i=1

if h<=0 or w<=0:
    print('Invalid input, program terminates.')
else:
    while count<=h:
        while i<=w:
            if count%2!=0:
                print('* ',end='')
            else:
                print(' *',end='')
            i+=1
        print()
        i=1
        count+=1

