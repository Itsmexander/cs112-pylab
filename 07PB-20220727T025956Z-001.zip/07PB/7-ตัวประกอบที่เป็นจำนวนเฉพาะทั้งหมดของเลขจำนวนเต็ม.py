n=int(input('Enter positive integer: '))
count=2
if n<=0:
    print('Invalid number.')
else:
    while count<=n:
        if n%count==0:
            print(count)
            n=n/count
        elif n%count!=0:
            count+=1
