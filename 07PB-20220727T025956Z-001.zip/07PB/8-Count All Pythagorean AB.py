n=int(input())
x=1
count=0
while x<=n :
    j=1
    while j<=n :
        if (x**2)+(j**2)==(n**2):
            count+=1
        j+=1
    x+=1
print("%d"%(count/2))