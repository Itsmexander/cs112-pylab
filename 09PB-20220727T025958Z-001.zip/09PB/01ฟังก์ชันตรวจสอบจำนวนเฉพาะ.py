def check_prime(n):
    if n<=1:
        return False
    else:
        num=2
        total=0        
        while num<n:          
            a=n%num
            if a!=0:
                total=total
            elif a==0:
                total+=1
            num+=1
            
        if total==0:
            return True
        else:
            return False