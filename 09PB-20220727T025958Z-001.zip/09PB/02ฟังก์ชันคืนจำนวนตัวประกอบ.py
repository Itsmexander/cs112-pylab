def factor_count(n):
    num=0
    count=1
    while count<=n:
        if n%count==0:
            num+=1
        else:
            num=num
        count+=1
    return num