def nb_year(p0, percent, aug, p):
    num=p0
    day=0
    while num<p:
        num=int(p0+(p0*percent/100)+aug)
        p0=num
        day+=1
    return day