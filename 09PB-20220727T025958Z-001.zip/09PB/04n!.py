def factorial(n):
    num=1
    count=1
    while count<=n:
        num*=count
        count+=1
    return num

n = int(input("Enter n: "))
print("%d!"%n, "=", factorial(n))