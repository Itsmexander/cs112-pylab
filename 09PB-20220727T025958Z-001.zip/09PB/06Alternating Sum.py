def Alternating_sum(n):
    count=2
    num=1
    while count<=n:
        if count%2!=0:
            num+=count
        elif count%2==0:
            num-=count
        count+=1
    return num

n = int(input("Enter n of series: "))
print("Alternating Sum from 1 to %d is %d" % (n,Alternating_sum(n)))