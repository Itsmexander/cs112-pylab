list = []

count = 0
i=0
while count < 20:
    score = int(input("Enter score: "))
    if 0 <= score <= 10 :
        list.append(score)
        count += 1
    else :
        print("Score is out of range.")
        count = count

print("Original list:")
print(list)

while i <= 10:
    star = "*"*list.count(i)
    print("%2d %s"%(i,star))
    i += 1
