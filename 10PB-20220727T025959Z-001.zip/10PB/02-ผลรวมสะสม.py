def accum(x):
    totals = []
    total = 0
    for num in range(0,len(x)) :
        total += x[num]
        totals.append(total)
    return totals



list = []
count = 0
i = 0

while True :
    score = int(input("Enter a number (0 to end): "))
    if 1 <= score <= 999 :
        list.append(score)
        count += 1
    elif score == 0 :
        print("Original list:")
        print(list)   
        print("Accumulative Sum:")
        ls = accum(list)
        for i in ls:
            print(i)
        break
    else :
        print("Number is out of range.")