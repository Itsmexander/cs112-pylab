def find_sd(l) :
    average = sum(l) / len(l)
    summ = 0
    for i in l :
        summ += (i - average)**2 
    SD = (summ / (len(l)-1))**(1/2) 
    return SD
        

ls = []
while True :
    score = float(input("Enter score: "))
    if score == -1 :
        if len(ls) != 0:
            print("Maximum score is %.2f."%max(ls))
            print("Minimum score is %.2f."%min(ls))
            print("Average score is %.2f."%(sum(ls)/len(ls)))
            print("Standard deviation is %.2f."%find_sd(ls))
        break
    elif 0 <= score <= 100 :
        ls.append(score)
            
    else :
        print("Score is out of range.")