def find_mode(l) :
    collect = [0] * 10
    ls_maxx = []
    maxx = 0
    maxx_str = 0
    for i in range(11) :
        col = l.count(i)
        if col > maxx :
            maxx = col 
            ls_maxx = []
            ls_maxx.append(i)
        elif col == maxx :
            maxx = col
            ls_maxx.append(i)
    return ls_maxx
    
        
    
i = 0
ls = []
while True :
    score = int(input("Enter score: "))
    if 0 <= score <= 10:
        ls.append(score)
        i += 1
    else : 
        print("Score is out of range.")
    if i == 20 :
        break

print("-----")
print("Original list:")
print(ls)
print("Mode of scores:")
ls_maxx = find_mode(ls)
for i in ls_maxx :
    print(i)

