ls = []
count = 1 
while True :
    num = int(input())
    if count == 1 :
        num_before = num
    if num == -1 :
        print(ls)
        break    
    elif num >= num_before :
        ls.append(num)
        num_before = num
    elif num == -1 :
        print(ls)
        break
    else : 
        pass
    count += 1
