def remove_duplicates(t):
    ls = []
    for i in t :
        if ls.count(i) == 0 :
            ls.append(i)
    return ls
    