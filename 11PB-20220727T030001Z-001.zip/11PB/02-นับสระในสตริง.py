ls = ['a', 'A', 'e', 'E', 'i', 'I', 'o', 'O', 'u', 'U']
text = input()
total = 0
for i in ls :
    summ = text.count(i)
    total += summ
    
print(total)
