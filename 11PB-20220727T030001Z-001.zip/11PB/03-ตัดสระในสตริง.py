text = input()
vowel = ['a', 'A', 'e', 'E', 'i', 'I', 'o', 'O', 'u', 'U']
for i in vowel :
    text = text.replace(i,"")
    
print(text)