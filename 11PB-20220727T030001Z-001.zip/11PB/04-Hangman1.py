text = input()
total = len(text)
ls = []
ls_have = []
have = 0

while True :
    inp = input()
    if inp == '0' :
        break
    else :
        ls.append(inp)
        
for i in ls :
    if i in text :
        c = text.count(i)
        if ls_have.count(i) == 0 :
            have += c
            ls_have.append(i)
        
print("%d/%d"%(have, total))
