elab = input()
test = input()
elab.upper()
test.upper()  
total = 0

for i in elab :
    if i in test :
        total += 1
        

if len(elab) <= 2:
    totals = 1
else :
    totals = len(elab)-2
    
print(total)
print("%.2f"%(total/totals*100))
