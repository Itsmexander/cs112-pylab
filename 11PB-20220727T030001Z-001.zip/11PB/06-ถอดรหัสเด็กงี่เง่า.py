text = input()
crazy = ["apa", "epe", "ipi", "opo", "upu"]
for i in crazy :
    if i in text:
        text = text.replace(i, i[0])

print(text)
