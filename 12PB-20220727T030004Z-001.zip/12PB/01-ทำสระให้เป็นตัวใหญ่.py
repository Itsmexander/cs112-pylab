vowel = ['a', 'A', 'e', 'E', 'i', 'I', 'o', 'O', 'u', 'U']

b = input()
for i in range(len(b)) :
    if b[i] in vowel :
        e = b[i].upper()
        print(e, end='')
    else :
        e = b[i].lower()
        print(e, end='')