text = input()
text = text.split(",")
for i in range(len(text)) :
    text[i] = text[i].strip()
    if i == 0 :
        print('"',end="")
        print(text[i],end="")
        print('"',end="")
    else :
        print(",",end="")
        print('"',end="")
        print(text[i],end="")
        print('"',end="")     