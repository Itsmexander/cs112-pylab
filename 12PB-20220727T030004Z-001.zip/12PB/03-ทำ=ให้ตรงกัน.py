import math
ls_before = []
ls_after = []
maxx = -(math.inf)
while True :
    text = input()
    if text == "-1" :
        break
    else :
        text = text.split("=",1)
        ls_before.append(text[0])
        ls_after.append(text[-1])
       
for i in ls_before :
    i = i.strip()    
    if len(i) > maxx :
        maxx = len(i)

for i in range(len(ls_before)) :
    ls_before[i] = ls_before[i].strip()
    print(" "*(maxx-len(ls_before[i]))+ls_before[i]+" "+"="+" ",end="")
    ls_after[i] = ls_after[i].strip()
    print(ls_after[i])
