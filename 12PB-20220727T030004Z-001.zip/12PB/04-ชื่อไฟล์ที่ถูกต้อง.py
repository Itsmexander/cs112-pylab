text = input()

notuse = '\ / * : | " < >'
if text.rfind('.') == -1 :
    for i in text :
        if i == ' ' :
            text = text.replace(' ', '_')
        for i in notuse :
            text = text.replace(i, '_')
    print(text[:15])
    
else :
    text = text.split('.')
    name = text[:-1]
    for i in range(len(name)) :
        for j in name[i] :
            if j in notuse :
                name[i] = name[i].replace(j, '_')
    name = ('_'.join(name))[:15]
    for i in text[-1] :
        if i in notuse :
            text[-1] = text[-1].replace(i, '_')
    surname = text[-1][:3]
    print('%s.%s'%(name,surname))