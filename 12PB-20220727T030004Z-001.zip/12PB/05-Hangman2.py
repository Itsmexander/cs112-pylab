text = input()
text_str = ""
while True :
    char = input()
    if char == "0" :
        break
    elif char not in text_str :
        text_str += char 
for i in text :
    if i not in text_str :
        text = text.replace(i,"-")
        
print(text)