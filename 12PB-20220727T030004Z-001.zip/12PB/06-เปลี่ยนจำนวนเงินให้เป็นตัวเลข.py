def check_digit(text) :
    text = text.replace(',', '').replace('.', '')
    if text.isdigit() :
        return True
    return False

def check_dot(text) :
    if text.count('.') > 1 :
        return False
    if text.count('.') == 1 :
        if len(text[text.find('.'):]) > 3 :
            return False
    return True
    
def check_comma(text) :
    if text.count('.') == 1 :
        text = text[:text.find('.')]
    if text.count(',') != 0 :
        if text[0] == ',':
            return False
        text = text.split(',')
        if len(text[0]) > 3 :
            return False        
        for i in range(1,len(text)) :
            if len(text[i]) != 3 :
                return False
    return True
     
    
text = input()
if check_digit(text) and check_comma(text) and check_dot(text) :
    text = float(text.replace(',', ''))
    if int(text) != text :
        print(text+1)
    else :
        print(int(text)+1)
else:
    print('ERROR')