text = input()
notuse = "-_=.$"
for i in range(len(text)) :
    if text[i] in notuse :
        text = text.replace(text[i], " ")

if text != "" :        
    text = (text.title()).replace(" ", "")
    text = text[0].lower()+text[1:]
    print(text)