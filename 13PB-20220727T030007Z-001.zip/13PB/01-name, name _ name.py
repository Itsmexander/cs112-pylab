def namelist(names):
    if len(names) == 1 :
        return names[0]
    elif len(names) == 2 :
        return " & ".join(names)
    elif len(names) == 0 :
        return ""
    else :
        nam = names[:]
        names = names[:-1]
        return ", ".join(names)+" & "+nam[-1]
        
print( namelist(['Bart', 'Viola', 'Peter', 'Nostel']) )       
print( namelist([]) == '' )        
print( namelist(['Bart', 'Viola']) )
print( namelist(['Peter']) )