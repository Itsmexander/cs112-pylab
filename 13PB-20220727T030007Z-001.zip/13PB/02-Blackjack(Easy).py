num = int(input())
count = 1
while count <= num :
    put = input()
    point = 0
    i = 0
    put = put.split()
    while i <= (len(put)-1) :
        if put[i] == 'A' :
            point += 1
        elif put[i] == '2' :
            point += 2 
        elif put[i] == '3' :
            point += 3
        elif put[i] == '4' :
            point += 4
        elif put[i] == '5' :
            point += 5 
        elif put[i] == '6' :
            point += 6
        elif put[i] == '7' :
            point += 7
        elif put[i] == '8' :
            point += 8 
        elif put[i] == '9' :
            point += 9
        elif put[i] == '10' or put[i] == 'J' or put[i] == 'Q' or put[i] == 'K':
            point += 10 

        if point > 16 :
            break
        i += 1
        
    if point > 21 :
        print('busted')
    else :
        print(point)
    count += 1
