def change(a, b) :
    return a // b

num = int(input())
count = 1
ls = []
while count <= num :
    money = int(input())
    ls.append(money)
    count += 1
ls.sort(reverse=True)
ls_num = []
money_give = int(input())
index = 0
while money_give != 0:
    n = change(money_give, ls[index])
    ls_num.append(n)
    money_give = money_give - (ls[index]*n)
    index += 1 

for i in range(len(ls)) :
    print("%d: %d"%(ls[i], ls_num[i]))
    
    