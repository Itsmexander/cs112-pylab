f1 = input()
f2 = input()
sun = int(input())
d1 = int(f1.split('-')[0])
d2 = int(f2.split('-')[0])
m1 = int(f1.split('-')[1])
m2 = int(f2.split('-')[1])
error = []
day = [0,31,28,31,30,31,30,31,31,30,31,30,31,31]
if not 1 <= m1 <= 12 :
    m1 = 13
if not 1 <= m2 <= 12 :
    m2 = 13
if m1 == 13 or m2 == 13 :
    print('Wrong Month')
    error.append('m')
if not 1 <= d1 <= day[m1] :
    d1 = 0
if not 1 <= d2 <= day[m2] :
    d2 = 0
if not 1 <= sun <= 7 :
    sun = 0
if d1 == 0 or d2 == 0 or sun == 0 :
    print('Wrong Day')
    error.append('d')
if len(error) == 0 :
    dayall1 = (sum(day[:m1]) + d1 - sun) // 7
    dayall2 = (sum(day[:m2]) + d2 - sun) // 7
    n = abs(dayall1 - dayall2)
    print(n)
