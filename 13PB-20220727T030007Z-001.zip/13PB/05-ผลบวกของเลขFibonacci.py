def fibo(n):
    fi = 1
    if n != 0 and n != 1 :
        n1,n2 = 1,1
        for i in range(n-1) :
            fi = n1 + n2
            n1 = n2
            n2 = fi
    return fi

def smfibo(n,e):
    sm = list()
    if n < 0 : return 'ERROR'
    if e == 'E' or e == 'e' :
        i = 0
    elif e == 'O' or e == 'o' and n != 0:
        i = 1
    else : return 'ERROR'
    while i <= n :
        sm.append(fibo(i))
        i += 2    
    return sum(sm)
    

n = int(input())
s = input()
print(smfibo(n,s))

