def check_order(l):
    if len(l) == 0 : return 'The list is empty.'
    if max(l) == min(l) : return 'The list is in non-increasing and non-decreasing order.'
    c = list()
    for i in range(len(l)) :
        if i != 0 :
            if l[i] >= l[i-1] :
                c.append(1)
            else :
                c.append(2)
    if max(c) != min(c) :
        return 'The list is in random order.'
    if max(c) == 1 :
        return 'The list is in non-decreasing order.'
    if max(c) == 2 :
        return 'The list is in non-increasing order.'
num = list()
while True :
    n = int(input('Enter a number (-1 to end): '))
    if n == -1 : break
    if not 0 <= n <= 100 :
        print('Number is out of range.')
        continue
    num.append(n)
print('-----')
print('Original list:')
print(num)
print(check_order(num))
