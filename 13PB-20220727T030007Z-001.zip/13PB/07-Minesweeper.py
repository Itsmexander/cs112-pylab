table = input().split('x')
m = int(table[0])
n = int(table[1])
bomb = list()
for i in range(m) :
    bomb.append([0]*n)
nb = int(input())
for i in range(nb):
    xy = input().split(',')
    bomb[int(xy[0])][int(xy[1])] = '*'
for i in range(len(bomb)) :
    for j in range(len(bomb[i])) :
        if bomb[i][j] != '*' :
            c = 0
            if i != 0 :
                if j != 0 :
                    if bomb[i-1][j-1] == '*' : c+=1
                if bomb[i-1][j] == '*' : c+=1
                if j != len(bomb[i])-1 :
                    if bomb[i-1][j+1] == '*' : c+=1
            if j != 0 :
                if bomb[i][j-1] == '*' : c+=1
            if j != len(bomb[i])-1 :
                if bomb[i][j+1] == '*' : c+=1
            if i != len(bomb)-1 :
                if j != 0 :
                    if bomb[i+1][j-1] == '*' : c+=1
                if bomb[i+1][j] == '*' : c+=1
                if j != len(bomb[i])-1 :
                    if bomb[i+1][j+1] == '*' : c+=1
            bomb[i][j] += c
        print(bomb[i][j],end='')
    print()
