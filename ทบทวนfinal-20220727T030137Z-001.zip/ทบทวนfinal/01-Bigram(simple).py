text = input().lower() 
ls = []
for i in range(len(text)-1) :
    if ls.count(text[i:i+2]) == 0:
        ls.append(text[i:i+2])
ls.sort()
for i in ls :
    print(i)