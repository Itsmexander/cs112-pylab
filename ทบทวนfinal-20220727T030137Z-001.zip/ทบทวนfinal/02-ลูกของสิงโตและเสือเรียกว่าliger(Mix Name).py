dad = input()
mom = input()
son = ""

vowel = 'aeiou'
count = 0
for i in range(len(dad)) :
    if dad[i] in vowel :
        count += 1
    if count < 2 :
        son = son + dad[i]

count = 0
for i in range(len(mom)) :
    if mom[i] in vowel :
        count += 1
        if count == 1:
            continue
    if count >= 1 :
        son = son + mom[i]
if count == 0 :
    son = son + mom
    
print(son)