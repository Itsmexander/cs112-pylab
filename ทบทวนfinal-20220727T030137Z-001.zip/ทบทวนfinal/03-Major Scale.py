major = input()
n = int(input())
major = major.split(',')

if n == 1 :
    print(major[0])

else :
    major = major[1:]
    n = (n-1) % len(major) - 1
    print(major[n])
    
