text = input()
text = text.replace(" ", "")
new = ""
for i in text :
    if new.count(i) == 0 :
        new = new + i
original = input()
want = input()
show = ""
for i in want :
    if i in original :
        n = original.find(i)
        show = show + new[n]
    else :
        show = show + i
        
print(show)