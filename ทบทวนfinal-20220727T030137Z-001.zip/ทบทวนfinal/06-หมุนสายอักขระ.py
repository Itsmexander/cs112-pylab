s = input()
n = int(input())
if len(s) == 0 : a = ''
else :
    if abs(n) > len(s) :
        if n < 0 :
            n = (abs(n) % len(s)) * (-1)
        else : n = n % len(s)
    a = s[-1*(n):] 
    if n > 0 :
        a += s[:len(s)-n]
    elif n < 0 :
        a += s[:-1*(n)]
print(a)