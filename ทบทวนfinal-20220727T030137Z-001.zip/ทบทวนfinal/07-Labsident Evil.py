import math
damage = float(input())
hp = input()
hp = hp.split()
ls = []
total = 0
for i in range(len(hp)) :
    n = math.ceil(float(hp[i])/damage)
    total += n
    ls.append(total)
    
print(total)
for i in range(len(ls)) :
    if i == 0 :
        print(ls[i],end='')
    else :
        print("",ls[i],end='')