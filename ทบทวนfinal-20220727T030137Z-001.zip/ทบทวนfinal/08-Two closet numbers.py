import math
num = int(input())
count = 1
ls = []
while count <= num :
    n = int(input())
    ls.append(n)
    count += 1

ls.sort()

countt = 0
minn = math.inf
ls1 = []
ls2 = []
while countt < (len(ls)-1) :
    if (ls[countt+1] - ls[countt]) < minn :
        minn = ls[countt+1] - ls[countt]
        ls1 = []
        ls2 = []
        ls1.append(ls[countt])
        ls2.append(ls[countt+1])
        
    elif (ls[countt+1] - ls[countt]) == minn :
        ls1.append(ls[countt])
        ls2.append(ls[countt+1])
    countt += 1

for i in range(len(ls1)) :
    print(ls1[i], ls2[i])
    
    
