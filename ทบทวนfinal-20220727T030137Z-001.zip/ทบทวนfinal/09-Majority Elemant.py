import math

num = int(input())
count = 1
ls = []
while count <= num :
    element = input()
    ls.append(element)
    count += 1
maxx = -(math.inf)
ls_num = []
for i in ls :
    if ls_num.count(i) == 0:
        ls_num.append(i)
        if ls.count(i) > maxx :
            maxx = ls.count(i)
            maxx_str = i
            
if maxx <= num//2 :
    print("0")
else :
    print(maxx_str)