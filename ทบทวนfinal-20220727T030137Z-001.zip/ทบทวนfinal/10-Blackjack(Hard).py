n = input().split(' ')
h = list()
point = list()
for i in n :
    if sum(point) < 17 :
        h.append(i)
        if i == 'A' :
            point.append(1)
        elif not i.isdigit() :
            point.append(10)
        else : point.append(int(i))
if 'K' in h :
    print('K')
elif 'Q' in h :
    print('Q')
elif 'J' in h :
    print('J')
elif max(point) == 1 :
    print('A')
else : print(max(point))
if sum(point) > 21 :
    print('busted')
else : print(sum(point))