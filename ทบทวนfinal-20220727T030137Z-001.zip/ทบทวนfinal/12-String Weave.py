text = input()
if len(text) % 2 == 0 :
    i = 1
    while i <= (len(text)/2) :
        print(text[i-1],end='')
        print(text[-i],end='')
        i += 1
else :
    i = 1
    while i <= (len(text)//2) :
        print(text[i-1],end='')
        print(text[-i],end='')
        i += 1
    print(text[(len(text)//2)])