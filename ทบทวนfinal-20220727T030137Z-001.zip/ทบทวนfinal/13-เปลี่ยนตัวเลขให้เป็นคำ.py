num = input()
if num.isdigit():
    num = int(num)
    if 0 < num < 1000 :       
        st = num // 100
        nd = num%100//10
        rd = num%100%10
        if st == 1 :
            f = 'one'
        elif st == 2 :
            f = 'two'
        elif st == 3 :
            f = 'three'
        elif st == 4 :
            f = 'four'
        elif st == 5 :
            f = 'five'
        elif st == 6 :
            f = 'six'
        elif st == 7 :
            f = 'seven'
        elif st == 8 :
            f = 'eight'
        elif st == 9 :
            f = 'nine'
        if nd == 1 :
            if rd == 1 :
                s = 'eleven'
            elif rd == 2 :
                s =  'twelve'
            elif rd == 3 :
                s = 'thirteen'
            elif rd == 4 :
                s = 'fourteen'
            elif rd == 5 :
                s = 'fifteen'
            elif rd == 6 :
                s = 'sixteen'
            elif rd == 7 :
                s = 'seventeen'
            elif rd == 8 :
                s = 'eighteen'
            elif rd == 9 :
                s = 'nineteen'
        elif nd == 2 :
            s = 'twenty'
        elif nd == 3 :
            s = 'thirty'
        elif nd == 4 :
            s = 'forty'
        elif nd == 5 :
            s = 'fifty' 
        elif nd == 6 :
            s = 'sixty'
        elif nd == 7 :
            s = 'seventy' 
        elif nd == 8 :
            s = 'eighty'
        elif nd == 9 :
            s = 'ninety'         
        if rd == 1 :
            t = 'one'
        elif rd == 2 :
            t = 'two'
        elif rd == 3 :
            t = 'three'
        elif rd == 4 :
            t = 'four'
        elif rd == 5 :
            t = 'five'
        elif rd == 6 :
            t = 'six'
        elif rd == 7 :
            t = 'seven'
        elif rd == 8 :
            t = 'eight'
        elif rd == 9 :
            t = 'nine'
                    
        if num%100 == 0 and num > 0:
            print('%s-hundred'%f)
        elif num > 100 :
            if nd == 0 :
                print('%s-hundred-%s'%(f,t))
            elif nd == 1 or rd == 0:
                print('%s-hundred-%s'%(f,s))
            else :
                print('%s-hundred-%s-%s'%(f,s,t))
        elif num == 10 :
            print('ten')
        elif num > 10:
            if nd == 1 or rd == 0 :
                print(s)
            else :
                print('%s-%s'%(s,t))
        elif num == 0 :
            print('zero')
        elif num > 0 :
            print(t)
    else :
        print("ERROR")
else :
    print("ERROR")