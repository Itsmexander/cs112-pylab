text = input()
text = text.split()
for i in range(len(text)) :
    if i == (len(text)-1) :
        if text[i] not in ["for", "and", "with", "of"] :
            print(text[i].capitalize())
        else :
            print(text[i])   
    else : 
        if text[i] not in ["for", "and", "with", "of"] :
            print(text[i].capitalize()+" ",end='')
        else :
            print(text[i]+" ",end='')