text = input()
if len(text) % 2 == 0 :
    i = len(text) // 2 - 1 
    while i >= 0 :
        print(text[i],end='')
        i -= 1
    i = len(text) - 1
    while i >= len(text)//2 :
        print(text[i],end='')
        i -= 1
else :
    i = len(text) // 2 - 1
    while i >= 0 :
        print(text[i],end='')
        i -= 1
    print(text[len(text)//2],end='')
    i = len(text) - 1 
    while i >= len(text) // 2 + 1 :
        print(text[i],end='')
        i -= 1