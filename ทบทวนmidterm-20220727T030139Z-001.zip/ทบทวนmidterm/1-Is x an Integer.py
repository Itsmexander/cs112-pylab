x=float(input())
if x%1==0:
    print("%d is an integer."%(x))
else:
    print("%.1f is not an integer."%(x))