n=int(input())
total=1
while n>0:
    a=n%10
    if a%2==0:
        total=total*a
    else:
        total=total
    n=n//10

if total==1:
    print('-1')
else:
    print(total)