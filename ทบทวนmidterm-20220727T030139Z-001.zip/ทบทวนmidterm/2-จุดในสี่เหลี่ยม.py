print("Upper left corner coordinate:")
x=int(input("  << x axis: "))
y=int(input("  << y axis: "))
e=int(input("  << Eastern: "))
s=int(input("  << Southern: "))
print("Enter a coordinate:")
xx=int(input("  << x axis: "))
yy=int(input("  << y axis: "))

x2=x+e
y2=y-s

if x<=xx<=x2 and y>=yy>=y2:
    print(">>> (%.2f, %.2f) is inside the rectangle."%(xx,yy))
else:
    print(">>> (%.2f, %.2f) is not inside the rectangle."%(xx,yy))
    
    

