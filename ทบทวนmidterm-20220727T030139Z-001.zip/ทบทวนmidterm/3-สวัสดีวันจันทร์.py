day=int(input())
hour=int(input())
minute=int(input())

if day==1:
    d='sunday'
elif day==2:
    d='monday'
elif day==3:
    d='tuesday'
elif day==4:
    d='wednesday'
elif day==5:
    d='thursday'
elif day==6:
    d='friday'
elif day==7:
    d='saturday'
    
if hour==4 and minute>=1:
    b='morning'
elif 0<=hour<=4 or (hour==22 and minute>=1) or hour==23:
    b='night'
elif 19<=hour<=22 or (hour==18 and minute>=1):
    b='evening'
elif 13<=hour<=18 or (hour==12 and minute>=1):
    b='afternoon'
elif 5<=hour<=12:
    b='morning'

print('good-%s-%s.png'%(b,d))