a=int(input())
b=int(input())
c=int(input())
aa=a**2
bb=b**2
cc=c**2
if aa==bb+cc or bb==aa+cc or cc==aa+bb :
  print('True')
else:
  print('False')