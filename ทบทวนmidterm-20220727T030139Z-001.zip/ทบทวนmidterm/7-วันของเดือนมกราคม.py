a=int(input())
b=int(input())
c=(b-a)%7
if 1<=b<=31 and 1<=a<=7:
  if c==0:
    print('Sunday')
  elif c==1:
    print('Monday')
  elif c==2:
    print('Tuesday')
  elif c==3:
    print('Wednesday')
  elif c==4:
    print('Thursday')
  elif c==5:
    print('Friday')
  elif c==6:
    print('Saturday')
else:
  print('ERROR')