x = input()
n = int(input())
a = (n-1)%7

if 0<n<=31 and (x=="Sunday" or x=="Monday" or x=="Tuesday" or x=="Wednesday" or x=="Thursday" or x=="Friday" or x=="Saturday"):
    if x=="Sunday":
        if a==0:
            print('Sunday')
        elif a==1:
            print('Monday')
        elif a==2:
            print('Tuesday')
        elif a==3:
            print('Wednesday')
        elif a==4:
            print('Thursday')
        elif a==5:
            print('Friday')
        elif a==6:
            print('Saturday')
    elif x=="Monday":
    
        if a==0:
            print('Monday')
        elif a==1:
            print('Tuesday')
        elif a==2:
            print('Wednesday')
        elif a==3:
            print('Thursday')
        elif a==4:
            print('Friday')
        elif a==5:
            print('Saturday')
        elif a==6:
            print('Sunday')        
        
    elif x=="Tuesday":
        
        if a==0:
            print('Tuesday')
        elif a==1:
            print('Wednesday')
        elif a==2:
            print('Thursday')
        elif a==3:
            print('Friday')
        elif a==4:
            print('Saturday')
        elif a==5:
            print('Sunday')
        elif a==6:
            print('Monday')
            
    elif x=="Wednesday":
    
        if a==0:
            print('Wednesday')
        elif a==1:
            print('Thursday')
        elif a==2:
            print('Friday')
        elif a==3:
            print('Saturday')
        elif a==4:
            print('Sunday')
        elif a==5:
            print('Monday')
        elif a==6:
            print('Tuesday')   
            
    elif x=="Thursday":
    
        if a==0:
            print('Thursday')
        elif a==1:
            print('Friday')
        elif a==2:
            print('Saturday')
        elif a==3:
            print('Sunday')
        elif a==4:
            print('Monday')
        elif a==5:
            print('Tuesday')
        elif a==6:
            print('Wednesday')    
            
    elif x=="Friday":
       
        if a==0:
            print('Friday')
        elif a==1:
            print('Saturday')
        elif a==2:
            print('Sunday')
        elif a==3:
            print('Monday')
        elif a==4:
            print('Tuesday')
        elif a==5:
            print('Wednesday')
        elif a==6:
            print('Thursday')        
    
    elif x=="Saturday":
    
        if a==0:
            print('Saturday')
        elif a==1:
            print('Sunday')
        elif a==2:
            print('Monday')
        elif a==3:
            print('Tuesday')
        elif a==4:
            print('Wednesday')
        elif a==5:
            print('Thursday')
        elif a==6:
            print('Friday')        
else:
    print("ERROR")